"use strict";

var HELP_ICON_HTML = "<i class='fa fa-exclamation-circle' aria-hidden='true'></i>";



	



/* GENERAL TEXT FIELD FORM */
var TextFieldForm = {
    containerTag: '.textfield-form',
    validateForm: function (textfield_form) {
        var value = textfield_form.find('input').val();
        
        // Always uses the last label, so if a display:none label is placed underneath the visible
        // control label, that label's text will be shown when the field is empty and required
		var lbl = textfield_form.find("label:last").text().toLowerCase();
							
        if (textfield_form.attr('required') && value === '') {
            textfield_form.find('.field-help-block').html(HELP_ICON_HTML + ' Enter the ' + lbl);
            return false;
        }
        textfield_form.find('.field-help-block').html('');
        return true;
    }
};
TextFieldForm.initialize = function (textfield_form) {
    textfield_form.data('form-validate', TextFieldForm.validateForm);
    var input = textfield_form.find('input');
    input.on('blur', function () {
        var value = $(this).val();
        if (textfield_form.hasClass('has-error') && value !== '') {
            textfield_form.removeClass('has-error');
            textfield_form.find('.field-help-block').html('');
        }
    });
};
TextFieldForm.initializeAll = function () {
	alert("TextFieldForm.initializeAll");
    $(TextFieldForm.containerTag).each(function () {
        TextFieldForm.initialize($(this));
    });
};




/* GENERAL CHECKBOX FIELD FORM */
var CheckboxForm = {
    containerTag: '.checkbox-form',
    validateForm: function (checkbox_form) {
        var is_checked = checkbox_form.find('input').is(':checked');
		var lbl = checkbox_form.closest(".error-label");
	
		var errorMessage = "You must select to continue";
		if(lbl.val() === "") {
			errorMessage = "Select " + lbl.text().toLowerCase();
		}
		
        if (checkbox_form.attr('required') && !is_checked) {
            checkbox_form.find('.field-help-block').html(HELP_ICON_HTML + " " + errorMessage);
            return false;
        }
        checkbox_form.find('.field-help-block').html('');
        return true;
    }
};
CheckboxForm.initialize = function (checkbox_form) {
    checkbox_form.data('form-validate', CheckboxForm.validateForm);   
    var input = checkbox_form.find('input');
    input.on('blur, click', function () {
        var is_checked = $(this).is(':checked');
        if (checkbox_form.hasClass('has-error') && is_checked) {
            checkbox_form.removeClass('has-error');
            checkbox_form.find('.field-help-block').html('');
        }
    });
};
CheckboxForm.initializeAll = function () {
    $(CheckboxForm.containerTag).each(function () {
        CheckboxForm.initialize($(this));
    });
};



/* GENERAL DROPDOWN FIELD FORM */
var DropdownForm = {
    containerTag: '.dropdown-form',
    validateForm: function (dropdown_form) {
        var value = dropdown_form.find('select').val();
        if (dropdown_form.attr('required') && value === '') {
            dropdown_form.find('.field-help-block').html(HELP_ICON_HTML + ' Select an option');
            return false;
        }
        dropdown_form.find('.field-help-block').html('');
        return true;
    }
};
DropdownForm.initialize = function (dropdown_form) {
    dropdown_form.data('form-validate', DropdownForm.validateForm);
    var input = dropdown_form.find('select');
    input.on('blur', function () {
        var value = $(this).val();
        if (dropdown_form.hasClass('has-error') && value !== '') {
            dropdown_form.removeClass('has-error');
            dropdown_form.find('.field-help-block').html('');
        }
    });
};
DropdownForm.initializeAll = function () {
    $(DropdownForm.containerTag).each(function () {
        DropdownForm.initialize($(this));
    });
};






/* Forms have interface:
    Naming convention:  "type"Form eg. EmailForm, TextareaForm ...
    APIs:
        initializeAll(): initializes all form elements of this type on the page.  Must be called after DOM is ready
        ele.data('validate-form'): element has validation code attached to the 'validate-form' key so that validation code can be delegated to the element.  Returns true if form is valid, or returns false
        containerTag: the jQuery search string to find all occurrences of the form type
        
*/

var allFormTypes = [
    TextFieldForm, CheckboxForm, DropdownForm
];



function initializeAllForms(parentEle) {
    parentEle = (parentEle && parentEle.length > 0)? parentEle : $('html');
    allFormTypes.forEach(function (formType) {
        parentEle.find(formType.containerTag).each(function() {
            formType.initialize($(this));
        });
    });
}



function setFormColorState(form, state) {
    if (form.hasClass('login-form')) {
        return;
    }
    if (state) {
        // don't show green form.addClass('has-success');
        form.removeClass('has-error');
    } else {
        form.addClass('has-error');
		form.find(".form-control-feedback").removeClass("hidden");
        // don't show green form.removeClass('has-success');
    }
    form.removeClass('has-warning');
}

function getAllFormElements(parentEle, visibleOnly) {
    var allFormClassesSearchString = allFormTypes.map(function(formType) {
        return formType.containerTag + ((visibleOnly)? ':visible' : '');
    }).join(',');
    return parentEle.find(allFormClassesSearchString);
}


function validateElements(form_elements) {
    var allFormsValid = true;
    // Only show validate visible fields within the form
    var elementValidationResult = true;
    
    $.each(form_elements, function() {
        var validationFunction = $(this).data('form-validate');
        if (validationFunction) {
            elementValidationResult = validationFunction($(this));
            if (!elementValidationResult) {
                console.log("not valid element:");
                console.log($(this));
                allFormsValid = false;             
            }
            setFormColorState($(this), elementValidationResult);
        }
    });
    return allFormsValid;
}


// Validates visible children of the form - all levels deep
function validateVisibleChildElements(parentEle) {
    return validateElements(
        getAllFormElements(parentEle, true));
}

function validateChildElements(parentEle) {
    return validateElements(
        getAllFormElements(parentEle));
}



/*
	Purpose: Removes error style classes and messaging on form fields.  To be used when party type is switched
	Params: 
		parentElement - the root element under which all elements will be cleared of error styling
*/
function clearErrorStylingOn(parentElement) {
    parentElement.find('.has-error').each(function() {
        $(this).removeClass('has-error');
        $(this).find('.field-help-block').text('');
    });
}





$(document).ready(function() {
	initializeAllForms(); 		
});