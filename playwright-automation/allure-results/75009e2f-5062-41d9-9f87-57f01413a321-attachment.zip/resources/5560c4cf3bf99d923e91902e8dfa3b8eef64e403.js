
var getParameterByName = function (name) {
	"use strict";

	name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
	var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
		results = regex.exec(location.search);
	return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
};


function ScrollToElement(el) { 
	"use strict";

    $('html, body').animate({ 
        scrollTop: $(el).offset().top - 50 }, 
		'slow', function() { $(el).find("input:first").focus(); }
	);           
} 


