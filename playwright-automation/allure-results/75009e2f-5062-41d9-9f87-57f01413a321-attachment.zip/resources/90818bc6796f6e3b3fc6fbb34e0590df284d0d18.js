

function calculateAndSetHeights() {
	"use strict";
   
    var window_height = $(window).height();	
	var wrapper_height = $("#wrapper").height();
	var footer_height = $("footer").height();
	
	if( (wrapper_height+footer_height) < window_height) {
		/* If content isn't long, stick footer to bottom of window */	
		$("footer").removeClass("footer");
		$("footer").addClass("footer-stick-to-bottom");
		
	} else {
		/* If the content is longer than the window, just add at bottom of content */
		$("footer").removeClass("footer-stick-to-bottom");
		$("footer").addClass("footer");
	}
	
}

    
$(document).ready(function() {
	"use strict";
	calculateAndSetHeights();
});
$(window).resize(function() {
	"use strict";
	calculateAndSetHeights();
});
$(window).on("orientationchange",function() {
	"use strict";
	calculateAndSetHeights();
});



