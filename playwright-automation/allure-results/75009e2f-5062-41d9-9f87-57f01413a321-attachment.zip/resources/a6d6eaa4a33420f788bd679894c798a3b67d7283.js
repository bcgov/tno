var site = getParameterByName("site");
if(site == "") {
	site = 1;
}	
switch(site) {
	case "1": 
		$("#rpUrl").text("Log in to www.ldbwholesale.com");
		$("#login-to").text("Log in to www.ldbwholesale.com");
		
		$("#ldb").removeClass("hidden");
		$("header").find("a").addClass("site-title-with-logo");
		$("#other-option-bcsc").addClass("hidden");
		$("#other-options").addClass("hidden");
		
		customLogoSettings();
		
		break;
	case "2":
		$("#rpUrl").text("Log in to www.bceid.ca");
		$("#login-to").text("Log in to www.bceid.ca");
		
		$("#bceid").removeClass("hidden");
		$("header").find("a").addClass("site-title-with-logo");
		$("#other-option-bcsc").removeClass("hidden");
		
		customLogoSettings();
		
		break;
	case "3":
		$("#rpUrl").text("Residential Tenancy Branch");
		$("#login-to").text("Residential Tenancy Branch");
		
		$("#other-option-bcsc").removeClass("hidden");
		//$("#other-option-idir").addClass("hidden");
		break;
	case "4":
		$("#rpUrl").text("Log in to www.idimwiki.gov.bc.ca");
		$("#login-to").text("Log in to www.idimwiki.gov.bc.ca");
		
		$(".login-options").addClass("hidden");
		$("#other-options").addClass("hidden");
		break;
	case "5":
		$("#rpUrl").text("Log in to Society Filings");
		$("#registries").removeClass("hidden");
		$("header").find("a").addClass("site-title-with-logo");
		
		customLogoSettings();
		
		break;
	case "6":
		$("#rpUrl").text("Log in to www.data.bcassessment.ca");
		$("#login-to").text("Log in to www.data.bcassessment.ca");
		
		$("#bcaa").removeClass("hidden");
		$("header").find("a").addClass("site-title-with-logo");
		
		customLogoSettings();
		
		break;
		
	case "7":
		$("#rpUrl").text("Log in to www.mentoring.gov.bc.ca");
		$("#login-to").text("Log in to www.mentoring.gov.bc.ca");
		
		$("#mentoring").removeClass("hidden");
		$("header").find("a").addClass("site-title-with-logo");
		
		customLogoSettings();
		
		break;
		
		
	case "8":
		$("#rpUrl").html("Welcome to the CHARD Login Page. For more information or help with this service please go to: <a href='mailto:info.chardbc.ca'>info.chardbc.ca</a>");
		$("#login-to").html("Welcome to the CHARD Login Page. For more information or help with this service please go to: <a href='mailto:info.chardbc.ca'>info.chardbc.ca</a>");
		
		$("#chard").removeClass("hidden");
		$("header").find("a").addClass("site-title-with-logo");
		
		customLogoSettings();
		
		break;
	
	default:
		break;
}

function customLogoSettings() {
	$("#bcGov").removeClass("gov-brand");
	$("#bcGov").addClass("no-gov-brand");
}
